import "./App.css";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import ListUserComponent from "./components/ListUserComponent";
import HeaderComponent from "./components/HeaderComponent";
import FooterComponent from "./components/FooterComponent";
import CreateUserComponent from "./components/CreateUserComponent";
import Homepage from "./components/Homepage";
import Login from "./components/Login";

function App() {
  return (
    <div>
      <HeaderComponent />
      <div className="container">
        <Router>
          <Routes>
            <Route path="/"  element={<Homepage />} /> 
            <Route path="/login"  element={<Login />} /> 
            <Route path="/users" element={<ListUserComponent />} />
            <Route path="/add-user" element={<CreateUserComponent />} />
          </Routes>
        </Router>
      </div>
      <FooterComponent />
    </div>
  );
}

export default App;

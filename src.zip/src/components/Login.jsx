import React from 'react'
import { Link } from 'react-router-dom'
import { Navigate, useNavigate } from "react-router-dom";

export default function Login() {
    
  return (
    <div>
        <h2>Login Page Under Construction</h2>
        <h1> <h1 ><Link to = '/users'>Submit</Link></h1></h1>
  
    </div>
  )
}

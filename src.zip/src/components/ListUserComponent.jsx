import React, { Component, useEffect, useState } from 'react'
import { Navigate, useNavigate } from 'react-router-dom';
import UserService from '../services/UserService'

export default function ListUserComponent (props) {

    const [users, setUsers] = useState([]);
    const navigate = useNavigate();
    useEffect(() => { 
        UserService.getUsers().then((res) => {
            setUsers(res.data);
        })
    },[]);

    const cancel = () => {
        navigate("/login");
      };
    
    return (
        
      <div>
        
        <h2 className="text-center">Users</h2>
        <div className="row">
        <div className="col-md-12">
            <button className="btn btn-add btn-primary " onClick={()=>navigate("/add-user") }>Add User</button>
        </div>
        </div>
        <div className="row">
            <table className="table table-striped table-bordered table-hover">
                <thead>
                    <tr>
                        <th>User Name</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Action</th>
                    </tr>
                </thead> 

                <tbody> 
                    {
                        users && users.map(
                            user => 
                                <tr key={user.id}>
                                    <td>{user.firstName} {user.lastName}</td>
                                    <td>{user.emailId}</td> <td>{user.role}</td>
                                </tr>    
                            )
                    }
                </tbody>
            </table>
            </div>
            <button
                  className="btn btn-danger"
                  onClick={cancel}
                  style={{ marginLeft: "10x" }}
                >
                  Cancel
                </button>
      </div>
    )
  }


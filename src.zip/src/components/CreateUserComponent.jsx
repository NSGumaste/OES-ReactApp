import React, { Component, useState } from "react";
import UserService from "../services/UserService";
import { Navigate, useNavigate } from "react-router-dom";

export default function CreateUserComponent(props) {
  const navigate = useNavigate();
  const [firstName, setfirstName] = useState("");
  const [lastName, setlastName] = useState("");
  const [emailId, setemailId] = useState("");
  const [role, setrole] = useState("");

  const saveUser = (e) => {
    e.preventDefault();

    let user = {
      firstName: firstName,
      lastName: lastName,
      emailId: emailId,
      role: role,
    };
    console.log("user =>" + JSON.stringify(user));

    UserService.createUser(user).then((res) => {
      navigate("/users");
    });
  };
  const changefirstNameHandler = (event) => {
    setfirstName(event.target.value);
  };
  const changelastNameHandler = (event) => {
    setlastName(event.target.value);
  };

 const changeemailIdHandler = (event) => {
    setemailId(event.target.value);
  };
 const changeroleHandler = (event) => {
    setrole(event.target.value);
  };

 const cancel = () => {
    navigate("/users");
  };

  return (
    <div>
      <div className="container">
        <div className="row">
          <div className="card col-md-6 offset-md-3 offset-md-3">
            <h3 className="text-center">Add User</h3>
            <div className="card-body">
              <form>
                <div className="form-group">
                  <label>First Name</label>
                  <input
                    placeholder="First Name:"
                    name="firstName"
                    className="form-control"
                    value={firstName}
                    onChange={changefirstNameHandler}
                  />
                </div>
                <div className="form-group">
                  <label>Last Name</label>
                  <input
                    placeholder="Last Name:"
                    name="lasttName"
                    className="form-control"
                    value={lastName}
                    onChange={changelastNameHandler}
                  />
                </div>
                <div className="form-group">
                  <label>Email Id</label>
                  <input
                    placeholder="Email Id:"
                    name="emaidId"
                    className="form-control"
                    value={emailId}
                    onChange={changeemailIdHandler}
                  />
                </div>
                <div className="form-group">
                  <label>Role</label>
                  <input
                    placeholder="Role:"
                    name="role"
                    className="form-control"
                    value={role}
                    onChange={changeroleHandler}
                  />
                </div>
                <button className="btn btn-success" onClick={saveUser}>
                  Save
                </button>
                <button
                  className="btn btn-danger"
                  onClick={cancel}
                  style={{ marginLeft: "10x" }}
                >
                  Cancel
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
